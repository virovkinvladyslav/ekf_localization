#ifndef BFL_WRAPPER_CONFIG_H
#define BFL_WRAPPER_CONFIG_H

/* #undef __MATRIXWRAPPER_NEWMAT__ */
/* #undef __MATRIXWRAPPER_LTI__ */
#define __MATRIXWRAPPER_BOOST__

#define __RNGWRAPPER_BOOST__
/* #undef __RNGWRAPPER_LTI__ */
/* #undef __RNGWRAPPER_SCYTHE__ */

#endif
